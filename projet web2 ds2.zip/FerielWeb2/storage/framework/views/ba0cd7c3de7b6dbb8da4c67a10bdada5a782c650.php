<!DOCTYPE html>
<html lang="fr">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Mes Objectifs</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css" rel="stylesheet">
  <style>
    body {
      background-color: #f0f8ff;
      font-family: 'Arial', sans-serif;
    }
    .sidebar {
      width: 250px;
      height: 100vh;
      background: #f06292;
      color: white;
      position: fixed;
      top: 0;
      left: 0;
      padding: 20px;
      overflow-y: auto;
    }
    .sidebar h2 {
      font-size: 1.5rem;
      margin-bottom: 30px;
    }
    .sidebar a {
      color: white;
      display: block;
      margin-bottom: 15px;
      text-decoration: none;
      font-weight: bold;
    }
    .sidebar a:hover {
      text-decoration: underline;
      color: #d81b60;
    }
    .sidebar .sub-title {
      font-size: 0.9rem;
      color: #f8bbd0;
      margin-left: 10px;
      margin-bottom: 15px;
    }
    .sidebar .sub-title a {
      font-weight: normal;
      color: white;
      display: block;
      margin-top: 4px;
      margin-left: 10px;
    }
    .main-content {
      margin-left: 270px;
      padding: 20px;
    }
    .card-objective {
      min-height: 180px;
      border-radius: 10px;
      background: white;
      box-shadow: 0 2px 6px rgba(0,0,0,0.1);
      transition: 0.3s;
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      text-align: center;
    }
    .card-objective img {
      width: 60px;
      height: 60px;
      object-fit: cover;
      margin-bottom: 10px;
    }
    .card-objective:hover {
      box-shadow: 0 4px 12px rgba(0,0,0,0.2);
      background-color: #f06292;
    }
    .header {
      height: 60px;
      background: #ffffff;
      border-bottom: 1px solid #dee2e6;
      display: flex;
      align-items: center;
      justify-content: space-between;
      padding: 0 20px;
      margin-left: 250px;
      color: #d81b60;
    }
    .header .profile {
      display: flex;
      align-items: center;
      position: relative;
    }
    .header .user-icon {
      font-size: 1.5rem;
      color: #d81b60;
      cursor: pointer;
    }
    .search-bar input {
      padding-left: 30px;
    }
    .search-bar .bi-search {
      position: absolute;
      left: 10px;
      top: 50%;
      transform: translateY(-50%);
      color: #d81b60;
    }
    section {
      padding-top: 60px;
      margin-top: 40px;
    }
    .add-button {
      position: fixed;
      bottom: 30px;
      right: 30px;
      background-color: white;
      color: Black;
      border: 2px solid white;
      padding: 10px 20px;
      border-radius: 5px;
      font-size: 1rem;
      transition: background-color 0.3s;
    }
    .add-button:hover {
      background-color:rgb(241, 166, 191); 
    }
    .dropdown-menu {
      display: none;
      position: absolute;
      top: 40px;
      right: 0;
      background-color: white;
      border-radius: 5px;
      box-shadow: 0 4px 12px rgba(0,0,0,0.2);
      min-width: 180px;
    }
    .dropdown-menu a {
      color: #333;
      padding: 10px;
      text-decoration: none;
      display: block;
    }
    .dropdown-menu a:hover {
      background-color: #f8bbd0;
      color: #d81b60;
    }
  </style>
</head>
<body>

<!-- Sidebar -->
<div class="sidebar">
  <h2><a href="#" id="goalmap-link">GoalMap</a></h2>
  <a href="#mes-objectifs">Mes objectifs</a>
  <div class="sub-title">
      <a href="#ajoutes-recemment">Ajoutés récemment</a>
      <a href="#categories">Catégories</a>
      <a href="#creer-objectif">Créer un objectif</a>
    </div>
    <a href="<?php echo e(route('map')); ?>">Carte interactive</a>

  <a href="<?php echo e(route('calendar')); ?>">Calendrier</a>
  <a href="<?php echo e(route('ai-helper')); ?>">IA (générateur)</a>
</div>

<!-- Header -->
<div class="header">
  <div class="search-bar w-50 position-relative">
    <input type="text" class="form-control" placeholder="Rechercher un objectif...">
    <i class="bi bi-search"></i>
  </div>
  <div class="profile">
    <i class="bi bi-person-circle user-icon" id="user-icon"></i>
    <div class="dropdown-menu" id="dropdown-menu">
      <a href="#">Mon profil</a>
      <a href="#">Paramètres</a>
      <a href="#" id="logout-link">Se déconnecter</a>
    </div>
  </div>
</div>

<!-- Main Content -->
<div class="main-content">
<section id="mes-objectifs">
  <div class="d-flex justify-content-between align-items-center mb-3">
    <h1>Mes Objectifs</h1>
  </div>

  <!-- Ajoutés récemment (Sous-titre) -->
  <section id="ajoutes-recemment">
  <h3>Ajoutés récemment</h3>
  
  <?php $__empty_1 = true; $__currentLoopData = $objectifsParCategorie; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categorie => $objectifs): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
    <h4 class="mt-4"><?php echo e(ucfirst($categorie)); ?></h4>
    <div class="row row-cols-1 row-cols-md-2 row-cols-lg-3 g-4">
      <?php $__empty_2 = true; $__currentLoopData = $objectifs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $objectif): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_2 = false; ?>
        <div class="col">
          <div class="card card-objective p-3 h-100">
            <img src="https://cdn-icons-png.flaticon.com/512/1086/1086933.png" alt="Objectif" width="50">
            <h5><?php echo e($objectif->titre); ?></h5>
            <p><strong>Catégorie :</strong> <?php echo e(ucfirst($objectif->categorie)); ?></p>
            <?php if($objectif->date_limite): ?>
              <p><strong>Date limite :</strong> <?php echo e(\Carbon\Carbon::parse($objectif->date_limite)->format('d/m/Y')); ?></p>
            <?php endif; ?>
            <ul class="mt-3">
              <?php $__empty_3 = true; $__currentLoopData = $objectif->etapes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $etape): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_3 = false; ?>
                <li>
                  <?php echo e($etape->nom); ?> - <?php echo e(ucfirst($etape->statut)); ?>

                  <?php if($etape->date_limite): ?>
                    <small class="text-muted">(avant <?php echo e(\Carbon\Carbon::parse($etape->date_limite)->format('d/m/Y')); ?>)</small>
                  <?php endif; ?>
                </li>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_3): ?>
                <li class="text-muted">Aucune étape définie</li>
              <?php endif; ?>
            </ul>
          </div>
        </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_2): ?>
        <div class="col">
          <div class="card card-objective p-3 text-muted text-center">
            <img src="https://cdn-icons-png.flaticon.com/512/2748/2748614.png" alt="Vide" width="100">
            <h5>Aucun objectif pour cette catégorie</h5>
            <p>Vous n'avez pas encore défini d'objectif dans cette catégorie.</p>
          </div>
        </div>
      <?php endif; ?>
    </div>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
    <div class="alert alert-info">Aucun objectif trouvé.</div>
  <?php endif; ?>
</section>



    <!-- Catégories (Sous-titre) -->
<section id="categories">
  <h3 class="mt-5">Catégories</h3>
  <div class="row row-cols-1 row-cols-md-2 row-cols-lg-3 g-4 mt-3">
    <?php
      $cats = [
        ['sport', '🏋️‍♂️ Sport', '1041/1041916'],
        ['lecture', '📚 Lecture', '3039/3039439'],
        ['etudes', '🎓 Études', '2910/2910791'],
        ['projets', '💼 Projets', '854/854878'],
        ['sante', '❤️ Santé', '3064/3064197'],
      ];
    ?>
    <?php $__currentLoopData = $cats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as [$key, $label, $icon]): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="col">
      <a href="javascript:void(0);" class="text-decoration-none text-dark" onclick="openCategoryModal('<?php echo e($key); ?>', '<?php echo e($label); ?>')">
        <div class="card card-objective p-3 text-center">
          <img src="https://cdn-icons-png.flaticon.com/512/<?php echo e($icon); ?>.png" alt="<?php echo e($key); ?>" width="60">
          <h5><?php echo e($label); ?></h5>
        </div>
      </a>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </div>
</section>
<!-- Modal pour afficher les objectifs par catégorie -->
<div class="modal fade" id="categoryModal" tabindex="-1" aria-labelledby="categoryModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="categoryModalLabel">Objectifs - <span id="categoryTitle"></span></h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Fermer"></button>
      </div>
      <div class="modal-body">
        <!-- Liste des objectifs -->
        <div id="categoryObjectives"></div>
      </div>
    </div>
  </div>
</div>



    <!-- Créer un Objectif (Sous-titre) -->
    <section id="creer-objectif">
      <button class="add-button" data-bs-toggle="modal" data-bs-target="#createObjectifModal">+ Ajouter un objectif</button>
    </section>
  </section>
</div>

<!-- Modal pour créer un objectif -->
<div class="modal fade" id="createObjectifModal" tabindex="-1" aria-labelledby="createObjectifModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="createObjectifModalLabel">Créer un Objectif</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Fermer"></button>
      </div>
      <div class="modal-body">
        <form method="POST" action="<?php echo e(route('objectif.store')); ?>">
          <?php echo csrf_field(); ?>
          <input type="hidden" name="utilisateur_id" value="<?php echo e(auth()->user()->id ?? 1); ?>">

          <div class="form-group mb-3">
            <label for="titre">Titre</label>
            <input type="text" class="form-control" id="titre" name="titre" required>
          </div>

          <div class="form-group mb-3">
            <label for="description">Description</label>
            <textarea class="form-control" id="description" name="description" rows="3"></textarea>
          </div>

          <div class="form-group mb-3">
            <label for="date_limite">Date Limite</label>
            <input type="date" class="form-control" id="date_limite" name="date_limite">
          </div>

          <div class="form-group mb-3">
            <label for="categorie">Catégorie</label>
            <select class="form-control" id="categorie" name="categorie" required>
              <option value="">Choisir une catégorie</option>
              <option value="sport">Sport</option>
              <option value="lecture">Lecture</option>
              <option value="etudes">Études</option>
              <option value="projets">Projets</option>
              <option value="sante">Santé</option>
            </select>
          </div>

          <hr>
          <h6>Étapes</h6>
          <div id="etapes-container" class="mb-3"></div>
          <button type="button" class="btn btn-sm btn-outline-info" onclick="ajouterEtape()">+ Ajouter une étape</button>

          <div class="mt-4">
            <button type="submit" class="btn btn-success">Créer l’objectif</button>
          </div>
        </form>
      </div>
    </div>
  </div>
</div>
<!-- Modal de déconnexion -->
<div class="modal fade" id="logoutModal" tabindex="-1" aria-labelledby="logoutModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="logoutModalLabel">Confirmation</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Fermer"></button>
      </div>
      <div class="modal-body">
        Voulez-vous vous déconnecter ?
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Non</button>
        <form method="POST" action="<?php echo e(route('logout')); ?>">
          <?php echo csrf_field(); ?>
          <button type="submit" class="btn btn-danger">Oui</button>
        </form>
      </div>
    </div>
  </div>
</div>


<!-- Scripts -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script>
  // Ajout dynamique d'étapes
  let index = 0;
  function ajouterEtape() {
    const container = document.getElementById('etapes-container');
    const html = `
      <div class="border p-2 mb-2 rounded">
        <input type="text" name="etapes[${index}][nom]" class="form-control mb-2" placeholder="Nom de l'étape" required>
        <input type="date" name="etapes[${index}][date_limite]" class="form-control" placeholder="Date limite">
      </div>
    `;
    container.insertAdjacentHTML('beforeend', html);
    index++;
  }

  // Menu déroulant profil
  document.getElementById('user-icon').addEventListener('click', function() {
    const dropdownMenu = document.getElementById('dropdown-menu');
    dropdownMenu.style.display = dropdownMenu.style.display === 'block' ? 'none' : 'block';
  });

  // Fermer le menu si on clique à l'extérieur
  document.addEventListener('click', function(event) {
    const dropdownMenu = document.getElementById('dropdown-menu');
    const profileIcon = document.getElementById('user-icon');
    if (!profileIcon.contains(event.target) && !dropdownMenu.contains(event.target)) {
      dropdownMenu.style.display = 'none';
    }
  });
  
  // Fonction pour ouvrir le modal avec les objectifs d'une catégorie
  function openCategoryModal(categorie, label) {
    // Modifier le titre du modal
    document.getElementById('categoryTitle').textContent = label;

    // Faire une requête AJAX pour récupérer les objectifs de la catégorie
    fetch(`/objectifs/categorie/${categorie}`)
      .then(response => response.json())
      .then(data => {
        const objectivesContainer = document.getElementById('categoryObjectives');
        objectivesContainer.innerHTML = ''; // Clear previous content

        if (data.length === 0) {
          objectivesContainer.innerHTML = '<p>Aucun objectif dans cette catégorie.</p>';
        } else {
          data.forEach(objectif => {
            const objectifElement = document.createElement('div');
            objectifElement.classList.add('card', 'mb-3');
            objectifElement.innerHTML = `
              <div class="card-body">
                <h5 class="card-title">${objectif.titre}</h5>
                <p><strong>Catégorie:</strong> ${objectif.categorie}</p>
                ${objectif.date_limite ? `<p><strong>Date limite:</strong> ${new Date(objectif.date_limite).toLocaleDateString()}</p>` : ''}
                <ul>
                  ${objectif.etapes.map(etape => `
                    <li>${etape.nom} - ${etape.statut} ${etape.date_limite ? `(avant ${new Date(etape.date_limite).toLocaleDateString()})` : ''}</li>
                  `).join('')}
                </ul>
              </div>
            `;
            objectivesContainer.appendChild(objectifElement);
          });
        }

        // Afficher le modal
        const categoryModal = new bootstrap.Modal(document.getElementById('categoryModal'));
        categoryModal.show();
      })
      .catch(error => console.error('Erreur:', error));
  }
  // Ouvrir le modal de déconnexion
  document.getElementById('logout-link').addEventListener('click', function(e) {
    e.preventDefault();
    const modal = new bootstrap.Modal(document.getElementById('logoutModal'));
    modal.show();
  });

  // Lien GoalMap simple redirection
  document.getElementById('goalmap-link').addEventListener('click', function(e) {
    e.preventDefault();
    window.location.href = "<?php echo e(route('acceuil')); ?>"; // remplace 'accueil' si besoin
  });


</script>

</body>
</html>
<?php /**PATH C:\Users\ferie\FerielWeb2\resources\views/objectif.blade.php ENDPATH**/ ?>