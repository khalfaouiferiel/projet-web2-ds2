<!DOCTYPE html>
<html lang="fr">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Inscription - GoalMap</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <style>
  body {
    background: linear-gradient(to right, #f48fb1, #c2185b);
    color: white;
    height: 100vh;
    display: flex;
    align-items: center;
    justify-content: center;
  }
  .card {
    border-radius: 1rem;
    padding: 2rem;
    background-color: #ffffffdd;
    color: #000;
    width: 100%;
    max-width: 500px;
  }
  .btn-primary {
    background-color: #f06292;
    border: none;
    color: white;
  }
  .btn-primary:hover {
    background-color: #ec407a;
  }
  a {
    color: #d81b60;
  }
</style>

</head>
<body>

  <div class="card shadow">
    <h2 class="text-center mb-4">Créer un compte</h2>
    <form action="<?php echo e(route('register')); ?>" method="POST">
    <?php echo csrf_field(); ?>
      <div class="mb-3">
        <label for="name" class="form-label">Nom complet</label>
        <input type="text" class="form-control" id="nomcomplet" name="nomcomplet" required placeholder="Jean Dupont">
      </div>
      <div class="mb-3">
        <label for="email" class="form-label">Adresse e-mail</label>
        <input type="email" class="form-control" id="email" name="email" required placeholder="email@example.com">
      </div>
      <div class="mb-3">
        <label for="password" class="form-label">Mot de passe</label>
        <input type="password" class="form-control" id="password" name="password" required placeholder="********">
      </div>
      <div class="mb-3">
        <label for="password_confirmation" class="form-label">Confirmer le mot de passe</label>
        <input type="password" class="form-control" id="password_confirmation" name="password_confirmation" required>
      </div>
      <button type="submit" class="btn btn-primary w-100">S'inscrire</button>
    </form>
    <p class="mt-3 text-center">Déjà un compte ? <a href="<?php echo e(route('connexion')); ?>">Connectez-vous ici</a>.</p>
  </div>

</body>
</html>
<?php /**PATH C:\Users\ferie\FerielWeb2\resources\views/inscription.blade.php ENDPATH**/ ?>