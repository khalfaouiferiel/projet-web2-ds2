<!DOCTYPE html>
<html lang="fr">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>GoalMap - Accueil</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

  <style>
  body {
    background: linear-gradient(to right, #f8bbd0, #f06292);
    color: white;
    min-height: 100vh;
  }
  .hero {
    padding: 100px 0;
    text-align: center;
  }
  .btn-primary {
    background-color: #fff;
    color: #f06292;
    font-weight: bold;
    border: none;
  }
  .btn-primary:hover {
    background-color: #fce4ec;
    color: #d81b60;
  }
  .btn-outline-light {
    border-color: white;
    color: white;
  }
  .btn-outline-light:hover {
    background-color: #ffffff33;
    color: #fff;
  }
</style>

</head>
<body>

  <div class="container hero">
    <h1 class="display-4">Organisez votre vie comme une carte mentale</h1>
    <p class="lead">Définissezvos objectifs, suivez-les dans le temps et restez motivé(e)s chaque jour.</p>
    <a href="" class="btn btn-primary btn-lg m-2">Commencer</a>
    <!-- Lien vers la page de connexion -->
    <a href="{{ route('connexion') }}" class="btn btn-outline-light btn-lg m-2">Se connecter</a>
  </div>

</body>
</html>
