@extends('layouts.app')

@section('title', 'Assistant IA')

@section('content')
  <h2>Générateur Intelligent d'Étapes</h2>
  <form method="POST" action="{{ route('generate-steps') }}">
    @csrf
    <div class="mb-3">
      <label for="objectif" class="form-label">Décrivez votre objectif :</label>
      <textarea class="form-control" id="objectif" name="objectif" rows="4" required></textarea>
    </div>
    <button type="submit" class="btn btn-primary">Générer les étapes</button>
  </form>

  @if(session('steps'))
    <h4 class="mt-4">Étapes suggérées :</h4>
    <ul>
      @foreach(session('steps') as $step)
        <li>{{ $step }}</li>
      @endforeach
    </ul>
  @endif
@endsection
