@extends('layouts.app')

@section('title', 'Calendrier')

@section('styles')
  <link href="https://cdn.jsdelivr.net/npm/fullcalendar@6.1.8/main.min.css" rel="stylesheet">
  <style>#calendar { height: 80vh; }</style>
@endsection

@section('content')
  <h2>Calendrier des Objectifs</h2>
  <div id="calendar"></div>
@endsection

@section('scripts')
  <script src="https://cdn.jsdelivr.net/npm/fullcalendar@6.1.8/index.global.min.js"></script>
  <script>
    document.addEventListener('DOMContentLoaded', function () {
      const calendar = new FullCalendar.Calendar(document.getElementById('calendar'), {
        initialView: 'dayGridMonth',
        events: [
          { title: 'Lire un livre', start: '2025-05-05' },
          { title: 'Faire du sport', start: '2025-05-10' }
        ]
      });
      calendar.render();
    });
  </script>
@endsection
