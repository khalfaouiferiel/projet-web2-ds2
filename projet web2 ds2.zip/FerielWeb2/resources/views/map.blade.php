
<!DOCTYPE html>
<html lang="fr">
<head>
  <meta charset="UTF-8">
  <title>Mind Map Dynamique avec PHP</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
  <style>
    body {
      background-color: #ffeef2;
      color: #212529;
    }
    .mindmap {
      display: flex;
      flex-direction: column;
      align-items: center;
      gap: 40px;
      margin: 50px auto;
    }
    .level {
      display: flex;
      justify-content: center;
      gap: 30px;
      flex-wrap: wrap;
      position: relative;
    }
    .node {
      background: white;
      padding: 15px 25px;
      border-left: 5px solid #d63384;
      border-radius: 12px;
      font-weight: 600;
      box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
    }
  </style>
</head>
<body>

<div class="container text-center">
  <h2 class="mt-4">🧠 Carte mentale</h2>

  <div class="mindmap">
    <div class="level">
      <div class="node">🎯 Objectif principal</div>
    </div>

    <div class="level" id="etapes">
      <?php foreach ($etapes as $etape): ?>
        <div class="node"><?= htmlspecialchars($etape['nom_etape']) ?></div>
      <?php endforeach; ?>
    </div>
  </div>

  <button class="btn btn-primary mt-3" onclick="ajouterEtape()">➕ Ajouter une étape</button>
</div>

<script>
  let compteur = <?= count($etapes) + 1 ?>;

  function ajouterEtape() {
    const container = document.getElementById("etapes");
    const node = document.createElement("div");
    node.className = "node";
    node.innerText = "Étape " + compteur++;
    container.appendChild(node);
  }
</script>

</body>
</html>
