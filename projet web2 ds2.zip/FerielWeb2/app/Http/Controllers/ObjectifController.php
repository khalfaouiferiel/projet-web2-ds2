<?php

namespace App\Http\Controllers;

use App\Models\Objectif;
use Illuminate\Http\Request;
use App\Models\Etape;
use Illuminate\Support\Facades\DB;

class ObjectifController extends Controller
{
    /**
     * Affiche tous les objectifs (filtrable par catégorie).
     */
    public function index(Request $request)
    {
        $query = Objectif::with('etapes');

        // Filtrage par catégorie si spécifié
        if ($request->has('categorie')) {
            $query->where('categorie', $request->categorie);
        }

        // Récupérer les objectifs par catégorie
        $objectifsParCategorie = Objectif::with('etapes')
            ->orderBy('categorie')  // Optionnel: Trie par catégorie si besoin
            ->get()
            ->groupBy('categorie'); // Groupement par catégorie

        // Affiche la vue 'objectif' avec les objectifs groupés
        return view('objectif', compact('objectifsParCategorie'));
    }

    /**
     * Enregistre un nouvel objectif.
     */
    public function store(Request $request)
    {
        // Validation des données
        $validated = $request->validate([
            'titre' => 'required|string|max:255',
            'description' => 'nullable|string',
            'categorie' => 'required|in:sport,lecture,etudes,projets,sante',
            'date_limite' => 'nullable|date',
            'etapes' => 'nullable|array',
            'etapes.*.nom' => 'required_with:etapes|string|max:255',
            'etapes.*.date_limite' => 'nullable|date',
        ]);

        // Création de l’objectif
        $objectif = Objectif::create([
            'titre' => $validated['titre'],
            'description' => $validated['description'] ?? null,
            'categorie' => $validated['categorie'],
            'date_limite' => $validated['date_limite'] ?? null,
            'utilisateur_id' => auth()->id(),  // Utilise l'ID de l'utilisateur connecté
        ]);

        // Ajout des étapes si elles existent
        if (!empty($validated['etapes'])) {
            foreach ($validated['etapes'] as $etapeData) {
                $objectif->etapes()->create([
                    'nom' => $etapeData['nom'],
                    'date_limite' => $etapeData['date_limite'] ?? null,
                    'statut' => 'en cours',
                ]);
            }
        }

        // Redirige vers la liste des objectifs avec un message de succès
        return redirect()->route('objectif.liste')->with('success', 'Objectif créé avec succès.');
    }

    /**
     * Affiche un objectif spécifique.
     */
    public function show($id)
    {
        // Récupère l’objectif avec ses étapes associées
        $objectif = Objectif::with('etapes')->findOrFail($id);

        // Affiche la vue 'objectif.show' (dans resources/views/objectif/show.blade.php)
        return view('objectif.show', compact('objectif'));
    }

    /**
     * Mise à jour d’un objectif.
     */
    public function update(Request $request, $id)
    {
        // Récupère l’objectif à mettre à jour
        $objectif = Objectif::findOrFail($id);

        // Validation des nouvelles données
        $validated = $request->validate([
            'titre' => 'required|string|max:255',
            'description' => 'nullable|string',
            'categorie' => 'required|in:sport,lecture,etudes,projets,sante',
            'date_limite' => 'nullable|date',
        ]);

        // Mise à jour de l’objectif
        $objectif->update($validated);

        // Redirige vers la page de l’objectif mis à jour avec un message de succès
        return redirect()->route('objectif.show', $objectif->id)->with('success', 'Objectif mis à jour.');
    }

    /**
     * Suppression d’un objectif.
     */
    public function destroy($id)
    {
        // Récupère l’objectif à supprimer
        $objectif = Objectif::findOrFail($id);

        // Supprime l’objectif
        $objectif->delete();

        // Redirige vers la liste des objectifs avec un message de succès
        return redirect()->route('objectif.liste')->with('success', 'Objectif supprimé.');
    }

    /**
     * Affiche la carte mentale de l'objectif avec ses étapes.
     */
    public function map()
    {
        // Récupère les objectifs et les étapes associées à l'utilisateur connecté
        $objectifs = Objectif::with('etapes')->where('utilisateur_id', auth()->id())->get();

        // Affiche la vue 'objectif.map' (dans resources/views/objectif/map.blade.php)
        return view('objectif.map', compact('objectifs'));
    }

    /**
     * Récupère les objectifs d'une catégorie spécifique.
     */
    public function getObjectivesByCategory($categorie)
    {
        // Récupère les objectifs de cette catégorie avec les étapes
        $objectifs = Objectif::with('etapes')
            ->where('categorie', $categorie)
            ->orderBy('created_at', 'desc')
            ->get();

        // Renvoyer les objectifs au format JSON pour AJAX
        return response()->json($objectifs);
    }
}
