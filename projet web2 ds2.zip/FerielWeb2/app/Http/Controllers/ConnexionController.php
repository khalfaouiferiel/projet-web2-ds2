<?php
namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use App\Models\UtilisateurInscrit;
use Illuminate\Support\Facades\Log;

class ConnexionController extends Controller
{
    // Afficher le formulaire de connexion
    public function showConnexionForm()
    {
        return view('connexion');
    }

    // Traitement de la connexion
    public function connexion(Request $request)
    {
        // Debug: Vérifier les données reçues
        Log::debug('Tentative de connexion', ['email' => $request->email]);

        // Validation
        $credentials = $request->validate([
            'email' => 'required|email',
            'password' => 'required|min:6',
        ]);

        // Tentative d'authentification
        if (Auth::attempt($credentials, $request->remember)) {
            $request->session()->regenerate();
            Log::info('Connexion réussie', ['user_id' => Auth::id()]);
            
            // Rediriger vers la page des objectifs après la connexion réussie
            return redirect()->route('objectif.index'); // Correct

        }

        // Si échec, vérifier si l'email existe
        $userExists = UtilisateurInscrit::where('email', $request->email)->exists();
        
        return back()
            ->withInput($request->only('email', 'remember'))
            ->withErrors([
                'email' => $userExists 
                    ? 'Mot de passe incorrect' 
                    : 'Aucun compte associé à cet email',
            ]);
    }

    // Déconnexion
    public function logout(Request $request)
    {
        Auth::logout();
        $request->session()->invalidate();
        $request->session()->regenerateToken();
        return redirect()->route('acceuil');
    }
}
