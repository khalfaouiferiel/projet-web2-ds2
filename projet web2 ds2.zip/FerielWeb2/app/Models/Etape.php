<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

    class Etape extends Model
    {
        use HasFactory;
        protected $fillable = ['nom', 'date_limite', 'statut', 'objectif_id'];
    
        public function objectif()
        {
            return $this->belongsTo(Objectif::class);
        }
    }
