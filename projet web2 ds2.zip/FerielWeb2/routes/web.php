<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\InscriptionController;
use App\Http\Controllers\ConnexionController;
use App\Http\Controllers\ObjectifController;

// Accueil
Route::get('/', fn() => view('Acceuil'))->name('acceuil');


// Inscription
Route::get('/inscription', fn() => view('inscription'))->name('inscription');
Route::post('/register', [InscriptionController::class, 'register'])->name('register');

// Connexion
Route::get('/connexion', [ConnexionController::class, 'showConnexionForm'])->name('connexion');
Route::post('/connexion', [ConnexionController::class, 'connexion'])->name('connexion.submit');

// Déconnexion
Route::post('/logout', [ConnexionController::class, 'logout'])->name('logout');

// Objectifs (accessible uniquement si connecté)
Route::middleware(['auth'])->group(function () {
    // Liste des objectifs
    Route::get('/objectifs', [ObjectifController::class, 'index'])->name('objectif.index');

    // Formulaire de création d'un objectif (GET)
    Route::get('/objectifs/create', [ObjectifController::class, 'create'])->name('objectif.create');

    // Création d’un objectif (POST)
    Route::post('/objectifs', [ObjectifController::class, 'store'])->name('objectif.store');

    // Détail d’un objectif
    Route::get('/objectif/{id}', [ObjectifController::class, 'show'])->name('objectif.show');

    // Mise à jour
    Route::put('/objectif/{id}', [ObjectifController::class, 'update'])->name('objectif.update');

    // Suppression
    Route::delete('/objectif/{id}', [ObjectifController::class, 'destroy'])->name('objectif.destroy');

    // Carte mentale de l'objectif (avec les étapes)
    Route::get('/map', [ObjectifController::class, 'map'])->name('map');  // Appeler la méthode 'map' du contrôleur

    // Autres pages
    Route::get('/calendar', fn() => view('calendar'))->name('calendar');
    Route::get('/ai-helper', fn() => view('ai-helper'))->name('ai-helper');
});
Route::get('/objectifs/categorie/{categorie}', [ObjectifController::class, 'getObjectivesByCategory']);
