<!DOCTYPE html>
<html>
<head>
    <title>Générateur d'Objectifs</title>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/js/app.js']); ?>
</head>
<body>
    <div class="container">
        <form id="ai-form">
            <input type="text" name="goal" placeholder="Votre objectif" required>
            <select name="category" required>
                <option value="sport">Sport</option>
                <option value="etudes">Études</option>
            </select>
            <select name="difficulty" required>
                <option value="debutant">Débutant</option>
                <option value="intermediaire">Intermédiaire</option>
            </select>
            <button type="submit">Générer</button>
        </form>
        <div id="result"></div>
    </div>
</body>
</html><?php /**PATH C:\Users\ferie\FerielWeb2\resources\views/ai-helper.blade.php ENDPATH**/ ?>