<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Calendrier des Objectifs</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css" rel="stylesheet">
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
        }
        .sidebar {
            width: 250px;
            height: 100vh;
            background: #f06292;
            color: white;
            position: fixed;
            top: 0;
            left: 0;
            padding: 20px;
            overflow-y: auto;
        }
        .sidebar h2 {
            font-size: 1.5rem;
            margin-bottom: 30px;
        }
        .sidebar a {
            color: white;
            display: block;
            margin-bottom: 15px;
            text-decoration: none;
            font-weight: bold;
        }
        .sidebar a:hover {
            text-decoration: underline;
            color: #d81b60;
        }
        .sidebar .sub-title {
            font-size: 0.9rem;
            color: #f8bbd0;
            margin-left: 10px;
            margin-bottom: 15px;
        }
        .sidebar .sub-title a {
            font-weight: normal;
            color: white;
            display: block;
            margin-top: 4px;
            margin-left: 10px;
        }
        .header {
            height: 60px;
            background: #ffffff;
            border-bottom: 1px solid #dee2e6;
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 0 20px;
            margin-left: 250px;
            color: #d81b60;
        }
        .header .profile {
            display: flex;
            align-items: center;
            position: relative;
        }
        .header .user-icon {
            font-size: 1.5rem;
            color: #d81b60;
            cursor: pointer;
        }
        .search-bar input {
            padding-left: 30px;
        }
        .search-bar .bi-search {
            position: absolute;
            left: 10px;
            top: 50%;
            transform: translateY(-50%);
            color: #d81b60;
        }
        .dropdown-menu {
            display: none;
            position: absolute;
            top: 40px;
            right: 0;
            background-color: white;
            border-radius: 5px;
            box-shadow: 0 4px 12px rgba(0,0,0,0.2);
            min-width: 180px;
        }
        .dropdown-menu a {
            color: #333;
            padding: 10px;
            text-decoration: none;
            display: block;
        }
        .dropdown-menu a:hover {
            background-color: #f8bbd0;
            color: #d81b60;
        }
        .calendar {
            width: 100%;
            max-width: 800px;
            margin: 50px auto;
            padding: 20px;
            background-color: white;
            border-radius: 8px;
            box-shadow: 0px 0px 15px rgba(0, 0, 0, 0.1);
        }
        .calendar-header {
            display: flex;
            justify-content: space-between;
            margin-bottom: 10px;
        }
        .calendar-grid {
            display: grid;
            grid-template-columns: repeat(7, 1fr);
            gap: 10px;
        }
        .calendar-day {
            padding: 20px;
            border: 1px solid #ddd;
            text-align: center;
        }
        .event {
            background-color: #007bff;
            color: white;
            padding: 5px;
            border-radius: 5px;
            font-size: 12px;
        }
        .button {
            padding: 10px;
            cursor: pointer;
            background-color: #ff4081; /* Couleur rose */
            color: white;
            border: none;
            border-radius: 5px;
        }
        .button:hover {
            background-color: #d63384;
        }
        .emoji {
            font-size: 20px;
            margin-right: 5px;
        }
        .step-info {
            margin-top: 5px;
            font-size: 14px;
            color: #666;
        }
        /* Main Content */
        .main-content {
            margin-left: 270px;
            padding: 20px;
        }
    </style>
</head>
<body>
<!-- Sidebar -->
<div class="sidebar">
  <h2><a href="<?php echo e(route('acceuil')); ?>" id="goalmap-link">GoalMap</a></h2>
  <a href="<?php echo e(route('objectif.index')); ?>">Mes objectifs</a>
  <div class="sub-title">
      <a href="#ajoutes-recemment">Ajoutés récemment</a>
      <a href="#categories">Catégories</a>
      <a href="#creer-objectif">Créer un objectif</a>
  </div>
  <a href="<?php echo e(route('map')); ?>">Map</a>
  <a href="<?php echo e(route('calendrier')); ?>">Calendrier</a>

</div>

<!-- Header -->
<div class="header">
  <div class="search-bar w-50 position-relative">
    <input type="text" class="form-control" placeholder="Rechercher un objectif...">
    <i class="bi bi-search"></i>
  </div>
  <div class="profile">
    <i class="bi bi-person-circle user-icon" id="user-icon"></i>
    <div class="dropdown-menu" id="dropdown-menu">
      <a href="#">Mon profil</a>
      <a href="#">Paramètres</a>
      <a href="#" id="logout-link">Se déconnecter</a>
    </div>
  </div>
</div>

<div class="calendar">
    <div class="calendar-header">
        <!-- Boutons de navigation pour les mois -->
        <form action="<?php echo e(route('previous.month', ['year' => $currentDate->year, 'month' => $currentDate->month])); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <button type="submit" class="button">⬅️ Mois précédent</button>
        </form>

        <span><strong><?php echo e($currentDate->format('F Y')); ?></strong></span>

        <form action="<?php echo e(route('next.month', ['year' => $currentDate->year, 'month' => $currentDate->month])); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <button type="submit" class="button">Mois suivant ➡️</button>
        </form>
    </div>

    <div class="calendar-grid">
        <?php
            // Nombre de jours dans le mois actuel
            $daysInMonth = $currentDate->daysInMonth;
            $firstDayOfMonth = $currentDate->copy()->startOfMonth()->dayOfWeek; // Jour de la semaine du 1er jour du mois
        ?>

        <?php for($i = 1; $i <= $daysInMonth; $i++): ?>
            <div class="calendar-day">
                <span><?php echo e($i); ?></span>

                <!-- Afficher les objectifs et les étapes pour chaque jour -->
                <?php $__currentLoopData = $objectifs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $objectif): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if(Carbon\Carbon::parse($objectif->date_limite)->day == $i && Carbon\Carbon::parse($objectif->date_limite)->month == $currentDate->month): ?>
                        <div class="event">
                            <span class="emoji">🎯</span> <?php echo e($objectif->titre); ?>

                            
                            <?php $__currentLoopData = $objectif->etapes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $etape): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="step-info">
                                    <span class="emoji">📅</span> <?php echo e($etape->nom); ?> 
                                    <br>
                                    <strong>Statut :</strong> <?php echo e(ucfirst($etape->statut)); ?>

                                    <br>
                                    <strong>Date limite :</strong> <?php echo e(\Carbon\Carbon::parse($etape->date_limite)->format('d/m/Y')); ?>

                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                
                <!-- Afficher la date limite du prochain objectif -->
                <?php if($i == 1 && count($objectifs) > 0): ?>
                    <div class="step-info">
                        <strong>Date limite du prochain objectif :</strong> 
                        <?php echo e(\Carbon\Carbon::parse($objectifs->first()->date_limite)->format('d/m/Y')); ?>

                    </div>
                <?php endif; ?>
            </div>
        <?php endfor; ?>
    </div>
</div>

<!-- Modal de déconnexion -->
<div class="modal fade" id="logoutModal" tabindex="-1" aria-labelledby="logoutModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="logoutModalLabel">Confirmation</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Fermer"></button>
      </div>
      <div class="modal-body">
        Voulez-vous vous déconnecter ?
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Non</button>
        <form method="POST" action="<?php echo e(route('logout')); ?>">
          <?php echo csrf_field(); ?>
          <button type="submit" class="btn btn-danger">Oui</button>
        </form>
      </div>
    </div>
  </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.min.js"></script>
<script>
    // Gestion de la navigation du profil
    document.getElementById('user-icon').addEventListener('click', function () {
        document.getElementById('dropdown-menu').style.display = 'block';
    });

    document.getElementById('logout-link').addEventListener('click', function () {
        // Ouvrir un modal de confirmation
        new bootstrap.Modal(document.getElementById('logoutModal')).show();
    });
</script>
</body>
</html>
<?php /**PATH C:\Users\ferie\FerielWeb2\resources\views/calendrier.blade.php ENDPATH**/ ?>