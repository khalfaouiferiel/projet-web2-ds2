<!DOCTYPE html>
<html lang="fr">
<head>
  <meta charset="UTF-8">
  <title>Mind Map Dynamique avec PHP</title>
  <!-- Leaflet CSS -->
<link rel="stylesheet" href="https://unpkg.com/leaflet@1.7.1/dist/leaflet.css" />

<!-- Leaflet JS -->
<script src="https://unpkg.com/leaflet@1.7.1/dist/leaflet.js"></script>

  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css" rel="stylesheet">
  <style>
    body {
      background-color: #f0f8ff;
      font-family: 'Arial', sans-serif;
    }
    .sidebar {
      width: 250px;
      height: 100vh;
      background: #f06292;
      color: white;
      position: fixed;
      top: 0;
      left: 0;
      padding: 20px;
      overflow-y: auto;
    }
    .sidebar h2 {
      font-size: 1.5rem;
      margin-bottom: 30px;
    }
    .sidebar a {
      color: white;
      display: block;
      margin-bottom: 15px;
      text-decoration: none;
      font-weight: bold;
    }
    .sidebar a:hover {
      text-decoration: underline;
      color: #d81b60;
    }
    .sidebar .sub-title {
      font-size: 0.9rem;
      color: #f8bbd0;
      margin-left: 10px;
      margin-bottom: 15px;
    }
    .sidebar .sub-title a {
      font-weight: normal;
      color: white;
      display: block;
      margin-top: 4px;
      margin-left: 10px;
    }
    .card-objective {
      min-height: 180px;
      border-radius: 10px;
      background: white;
      box-shadow: 0 2px 6px rgba(0,0,0,0.1);
      transition: 0.3s;
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      text-align: center;
    }
    .card-objective img {
      width: 60px;
      height: 60px;
      object-fit: cover;
      margin-bottom: 10px;
    }
    .card-objective:hover {
      box-shadow: 0 4px 12px rgba(0,0,0,0.2);
      background-color: #f06292;
    }
    .header {
      height: 60px;
      background: #ffffff;
      border-bottom: 1px solid #dee2e6;
      display: flex;
      align-items: center;
      justify-content: space-between;
      padding: 0 20px;
      margin-left: 250px;
      color: #d81b60;
    }
    .header .profile {
      display: flex;
      align-items: center;
      position: relative;
    }
    .header .user-icon {
      font-size: 1.5rem;
      color: #d81b60;
      cursor: pointer;
    }
    .search-bar input {
      padding-left: 30px;
    }
    .search-bar .bi-search {
      position: absolute;
      left: 10px;
      top: 50%;
      transform: translateY(-50%);
      color: #d81b60;
    }
    section {
      padding-top: 60px;
      margin-top: 40px;
    }
    .add-button {
      position: fixed;
      bottom: 30px;
      right: 30px;
      background-color: white;
      color: Black;
      border: 2px solid white;
      padding: 10px 20px;
      border-radius: 5px;
      font-size: 1rem;
      transition: background-color 0.3s;
    }
    .add-button:hover {
      background-color:rgb(241, 166, 191); 
    }
    .dropdown-menu {
      display: none;
      position: absolute;
      top: 40px;
      right: 0;
      background-color: white;
      border-radius: 5px;
      box-shadow: 0 4px 12px rgba(0,0,0,0.2);
      min-width: 180px;
    }
    .dropdown-menu a {
      color: #333;
      padding: 10px;
      text-decoration: none;
      display: block;
    }
    .dropdown-menu a:hover {
      background-color: #f8bbd0;
      color: #d81b60;
    }
    /* Main Content */
    .main-content {
      margin-left: 270px;
      padding: 20px;
    }
    #map {
  height: 800px; /* Augmenter la hauteur pour mieux voir la carte */
  width: 100%;
}


  </style>
</head>
<body>

<!-- Sidebar -->
<div class="sidebar">
  <h2><a href="<?php echo e(route('acceuil')); ?>" id="goalmap-link">GoalMap</a></h2>
   <a href="<?php echo e(route('objectif.index')); ?>">Mes objectifs</a>
  <div class="sub-title">
      <a href="#ajoutes-recemment">Ajoutés récemment</a>
      <a href="#categories">Catégories</a>
      <a href="#creer-objectif">Créer un objectif</a>
    </div>
  <a href="<?php echo e(route('map')); ?>">Map</a>
  <a href="<?php echo e(route('calendrier')); ?>">Calendrier</a>

</div>

<!-- Header -->
<div class="header">
  <div class="search-bar w-50 position-relative">
    <input type="text" class="form-control" placeholder="Rechercher un objectif...">
    <i class="bi bi-search"></i>
  </div>
  <div class="profile">
    <i class="bi bi-person-circle user-icon" id="user-icon"></i>
    <div class="dropdown-menu" id="dropdown-menu">
      <a href="#">Mon profil</a>
      <a href="#">Paramètres</a>
      <a href="#" id="logout-link">Se déconnecter</a>
    </div>
  </div>
</div>
<!-- Main Content -->
<div class="main-content">
<h1>Carte des Objectifs</h1>
<div id="map"></div>
<!-- Modal de déconnexion -->
<div class="modal fade" id="logoutModal" tabindex="-1" aria-labelledby="logoutModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="logoutModalLabel">Confirmation</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Fermer"></button>
      </div>
      <div class="modal-body">
        Voulez-vous vous déconnecter ?
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Non</button>
        <form method="POST" action="<?php echo e(route('logout')); ?>">
          <?php echo csrf_field(); ?>
          <button type="submit" class="btn btn-danger">Oui</button>
        </form>
      </div>
    </div>
  </div>
</div>


<script>
  let compteur = <?= isset($etapes) ? count($etapes) + 1 : 1 ?>;

  function ajouterEtape() {
    const container = document.getElementById("etapes");
    const node = document.createElement("div");
    node.className = "node";
    node.innerText = "Étape " + compteur++;
    container.appendChild(node);
  }
</script>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script>
    // Lien GoalMap simple redirection
    document.getElementById('goalmap-link').addEventListener('click', function(e) {
        e.preventDefault();
        window.location.href = "<?php echo e(route('acceuil')); ?>"; // remplace 'acceuil' si besoin
    });
    
  // Gérer l'ouverture du menu profil
  document.getElementById('user-icon').addEventListener('click', function() {
    const dropdownMenu = document.getElementById('dropdown-menu');
    dropdownMenu.style.display = dropdownMenu.style.display === 'block' ? 'none' : 'block';
  });

  // Fermer le menu si on clique ailleurs
  document.addEventListener('click', function(event) {
    const dropdownMenu = document.getElementById('dropdown-menu');
    const profileIcon = document.getElementById('user-icon');
    if (!profileIcon.contains(event.target) && !dropdownMenu.contains(event.target)) {
      dropdownMenu.style.display = 'none';
    }
  });

  // Gérer la déconnexion
  document.getElementById('logout-link').addEventListener('click', function(e) {
    e.preventDefault();
    const modal = new bootstrap.Modal(document.getElementById('logoutModal'));
    modal.show();
  });

  const objectifs = <?php echo json_encode($objectifs, 15, 512) ?>;

// Initialisation de la carte
const map = L.map('map').setView([33.8869, 9.5375], 6); // La carte est centrée sur la Tunisie (latitude: 33.8869, longitude: 9.5375)

// Ajout du fond de carte OpenStreetMap
L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
    attribution: '&copy; OpenStreetMap contributors'
}).addTo(map);

// Fonction de géocodage via Nominatim
function geocodeAdresse(ville, pays, callback) {
    const adresse = encodeURIComponent(`${ville}, ${pays}`);
    const url = `https://nominatim.openstreetmap.org/search?format=json&q=${adresse}`;

    fetch(url)
        .then(res => res.json())
        .then(data => {
            if (data && data.length > 0) {
                console.log('Coordonnées géocodées:', data[0]); // Ajout d'un log ici
                callback({
                    lat: data[0].lat,
                    lon: data[0].lon
                });
            } else {
                console.error('Aucune donnée géographique trouvée pour', adresse);
            }
        })
        .catch(err => console.error("Erreur géocodage :", err));
}


// Affichage des objectifs
objectifs.forEach((objectif, index) => {
    if (objectif.ville && objectif.pays) {
        // Ajout d'un délai pour éviter le blocage par Nominatim
        setTimeout(() => {
            geocodeAdresse(objectif.ville, objectif.pays, (coords) => {
                L.marker([coords.lat, coords.lon])
                    .addTo(map)
                    .bindPopup(`
                        <div style="max-width: 220px;">
                            <h5>${objectif.titre}</h5>
                            <p><strong>Lieu :</strong> ${objectif.ville}, ${objectif.pays}</p>
                            <p><strong>Dates :</strong><br>Du ${objectif.date_debut ?? 'N/A'} au ${objectif.date_fin ?? 'N/A'}</p>
                            <p><strong>Description :</strong><br>${objectif.description ?? 'Aucune description fournie.'}</p>
                        </div>
                    `);
            });
        }, index * 1000); // délai entre les requêtes
    }
});

</script>

</body>
</html>
<?php /**PATH C:\Users\ferie\FerielWeb2\resources\views/map.blade.php ENDPATH**/ ?>