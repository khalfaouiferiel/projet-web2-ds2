<!DOCTYPE html>
<html lang="fr">
<head>
  <meta charset="UTF-8">
  <title>@yield('title', 'GoalMap')</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css" rel="stylesheet">
  <style>
    body {
      background-color: #f0f8ff;
      font-family: 'Arial', sans-serif;
    }
    .sidebar {
      width: 250px;
      height: 100vh;
      background: #f06292;
      color: white;
      position: fixed;
      top: 0;
      left: 0;
      padding: 20px;
      overflow-y: auto;
    }
    .sidebar a {
      color: white;
      display: block;
      margin-bottom: 15px;
      text-decoration: none;
      font-weight: bold;
    }
    .sidebar a:hover {
      text-decoration: underline;
      color: #d81b60;
    }
    .header {
      height: 60px;
      background: #ffffff;
      border-bottom: 1px solid #dee2e6;
      display: flex;
      align-items: center;
      justify-content: space-between;
      padding: 0 20px;
      margin-left: 250px;
      color: #d81b60;
    }
    .main-content {
      margin-left: 270px;
      padding: 20px;
    }
  </style>
  @yield('styles')
</head>
<body>

<!-- Sidebar -->
<div class="sidebar">
  <h2><a href="{{ route('objectifs') }}" style="color: white;">GoalMap</a></h2>
  <a href="{{ route('objectifs') }}">🏆 Mes objectifs</a>
  <a href="{{ route('map') }}">🗺️ Carte interactive</a>
  <a href="{{ route('calendar') }}">📅 Calendrier</a>
  <a href="{{ route('ai-helper') }}">🤖 IA - Générateur</a>
</div>

<!-- Header -->
<div class="header">
  <div>Bienvenue sur GoalMap</div>
  <div>
    <i class="bi bi-person-circle" style="font-size: 1.5rem;"></i>
  </div>
</div>

<!-- Contenu -->
<div class="main-content">
  @yield('content')
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
@yield('scripts')
</body>
</html>
