<!DOCTYPE html>
<html lang="fr">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Mes Objectifs</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css" rel="stylesheet">
  <style>
    body {
      background-color: #f0f8ff;
      font-family: 'Arial', sans-serif;
    }
    .sidebar {
      width: 250px;
      height: 100vh;
      background: #f06292;
      color: white;
      position: fixed;
      top: 0;
      left: 0;
      padding: 20px;
      overflow-y: auto;
    }
    .sidebar h2 {
      font-size: 1.5rem;
      margin-bottom: 30px;
    }
    .sidebar a {
      color: white;
      display: block;
      margin-bottom: 15px;
      text-decoration: none;
      font-weight: bold;
    }
    .sidebar a:hover {
      text-decoration: underline;
      color: #d81b60;
    }
    .sidebar .sub-title {
      font-size: 0.9rem;
      color: #f8bbd0;
      margin-left: 10px;
      margin-bottom: 15px;
    }
    .sidebar .sub-title a {
      font-weight: normal;
      color: white;
      display: block;
      margin-top: 4px;
      margin-left: 10px;
    }
    .main-content {
      margin-left: 270px;
      padding: 20px;
    }
    .card-objective {
      min-height: 180px;
      border-radius: 10px;
      background: white;
      box-shadow: 0 2px 6px rgba(0,0,0,0.1);
      transition: 0.3s;
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      text-align: center;
    }
    .card-objective img {
      width: 60px;
      height: 60px;
      object-fit: cover;
      margin-bottom: 10px;
    }
    .card-objective:hover {
      box-shadow: 0 4px 12px rgba(0,0,0,0.2);
      background-color: #f06292;
    }
    .header {
      height: 60px;
      background: #ffffff;
      border-bottom: 1px solid #dee2e6;
      display: flex;
      align-items: center;
      justify-content: space-between;
      padding: 0 20px;
      margin-left: 250px;
      color: #d81b60;
    }
    .header .profile {
      display: flex;
      align-items: center;
      position: relative;
    }
    .header .user-icon {
      font-size: 1.5rem;
      color: #d81b60;
      cursor: pointer;
    }
    .search-bar input {
      padding-left: 30px;
    }
    .search-bar .bi-search {
      position: absolute;
      left: 10px;
      top: 50%;
      transform: translateY(-50%);
      color: #d81b60;
    }
    section {
      padding-top: 60px;
      margin-top: 40px;
    }
    .add-button {
      position: fixed;
      bottom: 30px;
      right: 30px;
      background-color: white;
      color: black;
      border: 2px solid white;
      padding: 10px 20px;
      border-radius: 5px;
      font-size: 1rem;
      transition: background-color 0.3s;
    }
    .add-button:hover {
      background-color: rgb(241, 166, 191); 
    }
    .dropdown-menu {
      display: none;
      position: absolute;
      top: 40px;
      right: 0;
      background-color: white;
      border-radius: 5px;
      box-shadow: 0 4px 12px rgba(0,0,0,0.2);
      min-width: 180px;
    }
    .dropdown-menu a {
      color: #333;
      padding: 10px;
      text-decoration: none;
      display: block;
    }
    .dropdown-menu a:hover {
      background-color: #f8bbd0;
      color: #d81b60;
    }
  </style>
</head>
<body>

<!-- Sidebar -->
<div class="sidebar">
  <h2><a href="{{ route('acceuil') }}" id="goalmap-link">GoalMap</a></h2>
  <a href="#mes-objectifs">Mes objectifs</a>
  <div class="sub-title">
      <a href="#ajoutes-recemment">Ajoutés récemment</a>
      <a href="#categories">Catégories</a>
      <a href="#creer-objectif">Créer un objectif</a>
  </div>
  <a href="{{ route('map') }}">Map</a>
  <a href="{{ route('calendrier') }}">Calendrier</a>
</div>

<!-- HEADER MODIFIÉ -->
<div class="header">
  <div class="search-bar w-50 position-relative">
    <input type="text" class="form-control" placeholder="Rechercher un objectif...">
    <i class="bi bi-search"></i>
  </div>
  <div>
    <a href="{{ route('connexion') }}" class="btn btn-outline-primary me-2">Se connecter</a>
    <a href="{{ route('inscription') }}" class="btn btn-primary">Créer un compte</a>
  </div>
</div>
<!-- BOUTON "AJOUTER UN OBJECTIF" + MODALE -->
<button class="add-button" onclick="showLoginModal()">Ajouter un objectif</button>

<div class="modal fade" id="loginModal" tabindex="-1" aria-labelledby="loginModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content">
      <div class="modal-header bg-warning">
        <h5 class="modal-title" id="loginModalLabel">Connexion requise</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Fermer"></button>
      </div>
      <div class="modal-body">
        Vous devez être connecté pour ajouter un objectif.
      </div>
      <div class="modal-footer">
        <a href="{{ route('connexion') }}" class="btn btn-primary">Se connecter</a>
        <a href="{{ route('inscription') }}" class="btn btn-outline-secondary">Créer un compte</a>
      </div>
    </div>
  </div>
</div>


<!-- Main Content -->
<div class="main-content">
<section id="mes-objectifs">
  <div class="d-flex justify-content-between align-items-center mb-3">
    <h1>Mes Objectifs</h1>
  </div>

  <section id="ajoutes-recemment">
    <h3>Ajoutés récemment</h3>
    <div class="alert alert-warning">Vous devez être connecté pour voir vos objectifs.</div>
  </section>

  <!-- Catégories -->
  <section id="categories">
    <h3 class="mt-5">Catégories</h3>
    <div class="row row-cols-1 row-cols-md-2 row-cols-lg-3 g-4 mt-3">
      @php
        $cats = [
          ['sport', '🏋️‍♂️ Sport', '1041/1041916'],
          ['lecture', '📚 Lecture', '3039/3039439'],
          ['etudes', '🎓 Études', '2910/2910791'],
          ['projets', '💼 Projets', '854/854878'],
          ['sante', '❤️ Santé', '3064/3064197'],
        ];
      @endphp
      @foreach ($cats as [$key, $label, $icon])
      <div class="col">
        <a href="javascript:void(0);" class="text-decoration-none text-dark" onclick="openCategoryModal('{{ $key }}', '{{ $label }}')">
          <div class="card card-objective p-3 text-center">
            <img src="https://cdn-icons-png.flaticon.com/512/{{ $icon }}.png" alt="{{ $key }}" width="60">
            <h5>{{ $label }}</h5>
          </div>
        </a>
      </div>
      @endforeach
    </div>
  </section>
  <!-- SCRIPT JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script>
  function openCategoryModal(key, label) {
    alert('Vous devez être connecté pour voir les objectifs de la catégorie : ' + label);
  }

  function showLoginModal() {
    var loginModal = new bootstrap.Modal(document.getElementById('loginModal'));
    loginModal.show();
  }
</script>
</html>

