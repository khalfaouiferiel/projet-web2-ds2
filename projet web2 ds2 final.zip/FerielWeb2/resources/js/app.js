import './bootstrap';
document.getElementById('ai-form').addEventListener('submit', async (e) => {
    e.preventDefault();
    const formData = new FormData(e.target);

    try {
        const response = await fetch('/api/ai/generate', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').content
            },
            body: JSON.stringify({
                goal: formData.get('goal'),
                category: formData.get('category'),
                difficulty: formData.get('difficulty')
            })
        });

        const data = await response.json();
        document.getElementById('result').innerText = data.plan;
    } catch (error) {
        console.error('Erreur:', error);
    }
});