<?php

namespace App\Services;

use GuzzleHttp\Client;
use GuzzleHttp\Exception\RequestException;
use Illuminate\Support\Facades\Log;

class OpenAIService
{
    private Client $client;
    private string $apiKey;
    private string $model;

    public function __construct()
    {
        $this->apiKey = config('services.openai.key');
        $this->model = config('services.openai.model');

        if (empty($this->apiKey)) {
            throw new \RuntimeException('Clé API OpenAI manquante');
        }

        $this->client = new Client([
            'base_uri' => 'https://api.openai.com/v1/',
            'headers' => [
                'Authorization' => 'Bearer ' . $this->apiKey,
                'Content-Type' => 'application/json',
            ],
            'timeout' => 30.0
        ]);
    }

    public function generateGoalPlan(string $goal, string $category, string $difficulty): string
    {
        $prompt = "Crée un plan détaillé pour:\n\nCatégorie: $category\nDifficulté: $difficulty\nObjectif: $goal\n\nInclus des étapes claires avec des délais.";

        try {
            $response = $this->client->post('chat/completions', [
                'json' => [
                    'model' => $this->model,
                    'messages' => [
                        ['role' => 'user', 'content' => $prompt]
                    ],
                    'temperature' => 0.7,
                    'max_tokens' => 1000
                ]
            ]);

            $data = json_decode($response->getBody(), true);
            return $data['choices'][0]['message']['content'] ?? 'Erreur: réponse vide';

        } catch (RequestException $e) {
            Log::error('Erreur OpenAI', ['error' => $e->getMessage()]);
            return 'Service temporairement indisponible';
        }
    }
}