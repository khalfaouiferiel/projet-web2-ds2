<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use App\Models\UtilisateurInscrit;

class InscriptionController extends Controller
{
    public function register(Request $request)
    {
        $request->validate([
            'nomcomplet' => 'required|string|max:255', // Changé de 'name' à 'nomcomplet'
            'email' => 'required|email|unique:utilisateursinscrits,email',
            'password' => 'required|min:6|confirmed',
        ]);

        UtilisateurInscrit::create([
            'nomcomplet' => $request->nomcomplet, // Champ cohérent avec la BDD
            'email' => $request->email,
            'password' => Hash::make($request->password),
        ]);

        return redirect()->route('connexion')->with('success', 'Inscription réussie ! Connectez-vous.');
    }
}