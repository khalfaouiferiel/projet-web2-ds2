<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use OpenAI\Laravel\Facades\OpenAI;

class AIHelperController extends Controller
{
    public function generatePlan(Request $request)
    {
        $validated = $request->validate([
            'objective_type' => 'required|string',
            'difficulty' => 'required|string',
            'prompt' => 'required|string'
        ]);

        try {
            $response = OpenAI::completions()->create([
                'model' => 'text-davinci-003',
                'prompt' => $this->buildPrompt(
                    $validated['objective_type'],
                    $validated['difficulty'],
                    $validated['prompt']
                ),
                'max_tokens' => 1000,
                'temperature' => 0.7,
            ]);

            return response()->json([
                'plan' => trim($response['choices'][0]['text'])
            ]);

        } catch (\Exception $e) {
            return response()->json([
                'error' => $e->getMessage()
            ], 500);
        }
    }

    private function buildPrompt($type, $difficulty, $userPrompt)
    {
        return "En tant qu'expert en développement personnel, génère un plan détaillé par étapes pour atteindre cet objectif:\n\n" .
               "Type: $type\n" .
               "Niveau: $difficulty\n" .
               "Objectif: $userPrompt\n\n" .
               "Le plan doit inclure:\n- Des étapes claires et progressives\n- Des délais réalistes\n- Des conseils pratiques\n" .
               "Formatte la réponse en markdown avec des titres et listes.";
    }
}