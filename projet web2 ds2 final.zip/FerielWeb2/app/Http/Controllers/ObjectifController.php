<?php

namespace App\Http\Controllers;

use App\Models\Objectif;
use Illuminate\Http\Request;
use App\Models\Etape;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Auth;

class ObjectifController extends Controller
{
    /**
     * Affiche tous les objectifs (filtrable par catégorie).
     */
    public function index(Request $request)
    {
        $user = Auth::user();

        $query = $user->objectifs()->with('etapes');

        if ($request->filled('categorie')) {
            $query->where('categorie', $request->input('categorie'));
        }

        $objectifsParCategorie = $query
            ->orderBy('categorie')
            ->get()
            ->groupBy('categorie');

        return view('objectif', compact('objectifsParCategorie'));
    }

    /**
     * Enregistre un nouvel objectif.
     */
    public function store(Request $request)
    {
        $validated = $request->validate([
            'titre' => 'required|string|max:255',
            'description' => 'nullable|string',
            'categorie' => 'required|in:sport,lecture,etudes,projets,sante',
            'date_limite' => 'nullable|date',
            'ville' => 'nullable|string|max:255',
            'pays' => 'nullable|string|max:255',
            'etapes' => 'nullable|array',
            'etapes.*.nom' => 'required_with:etapes|string|max:255',
            'etapes.*.date_limite' => 'nullable|date',
        ]);
    
        // Création de l'objectif
        $objectif = Objectif::create([
            'titre' => $validated['titre'],
            'description' => $validated['description'] ?? null,
            'categorie' => $validated['categorie'],
            'date_limite' => $validated['date_limite'] ?? null,
            'utilisateur_id' => auth()->id(),
            'ville' => $validated['ville'] ?? null,
            'pays' => $validated['pays'] ?? null,
        ]);
    
        // Création des étapes associées à l'objectif
        if (!empty($validated['etapes'])) {
            foreach ($validated['etapes'] as $etapeData) {
                $objectif->etapes()->create([
                    'nom' => $etapeData['nom'],
                    'date_limite' => $etapeData['date_limite'] ?? null,
                    'statut' => 'en cours',
                ]);
            }
        }
    
        // Redirection vers la liste des objectifs
        return redirect()->route('objectif.index')->with('success', 'Objectif créé avec succès.');
    }
    
    /**
     * Affiche un objectif spécifique.
     */
    public function show($id)
    {
        $objectif = Objectif::with('etapes')->findOrFail($id);
        return view('objectif.show', compact('objectif'));
    }

    /**
     * Mise à jour d’un objectif.
     */
    public function update(Request $request, $id)
    {
        $objectif = Objectif::findOrFail($id);

        $validated = $request->validate([
            'titre' => 'required|string|max:255',
            'description' => 'nullable|string',
            'categorie' => 'required|in:sport,lecture,etudes,projets,sante',
            'date_limite' => 'nullable|date',
        ]);

        $objectif->update($validated);

        return redirect()->route('objectif.show', $objectif->id)->with('success', 'Objectif mis à jour.');
    }

    /**
     * Suppression d’un objectif.
     */
    public function destroy($id)
    {
        $objectif = Objectif::findOrFail($id);
        $objectif->delete();

        return redirect()->route('objectif.index')->with('success', 'Objectif supprimé.');
    }

    /**
     * Affiche la carte mentale de l'objectif avec ses étapes.
     */
    public function map()
    {
        $objectifs = Objectif::where('utilisateur_id', auth()->id())
            ->whereNotNull('ville')
            ->whereNotNull('pays')
            ->get();

        return view('map', compact('objectifs'));
    }

    /**
     * Récupère les objectifs d'une catégorie spécifique.
     */
    public function objectifsParCategorie($categorie)
    {
        $userId = Auth::id();

        $objectifs = Objectif::with('etapes')
            ->where('utilisateur_id', $userId)
            ->where('categorie', $categorie)
            ->get();

        return response()->json($objectifs);
    }
}
