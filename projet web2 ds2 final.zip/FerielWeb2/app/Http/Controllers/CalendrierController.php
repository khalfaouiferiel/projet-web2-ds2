<?php

namespace App\Http\Controllers;

use App\Models\Objectif;
use Carbon\Carbon;

class CalendrierController extends Controller
{
    public function index($year = null, $month = null)
    {
        if ($year == null || $month == null) {
            $year = 2025;
            $month = 5;
        }

        $currentDate = Carbon::create($year, $month, 1);

        // Récupérer les objectifs du mois
        $objectifs = Objectif::with('etapes')
            ->whereMonth('date_limite', $month)
            ->whereYear('date_limite', $year)
            ->get();

        return view('calendrier', compact('objectifs', 'currentDate'));
    }

    public function previousMonth($year, $month)
    {
        $previousMonth = Carbon::create($year, $month, 1)->subMonth();
        return redirect()->route('calendrier', ['year' => $previousMonth->year, 'month' => $previousMonth->month]);
    }

    public function nextMonth($year, $month)
    {
        $nextMonth = Carbon::create($year, $month, 1)->addMonth();
        return redirect()->route('calendrier', ['year' => $nextMonth->year, 'month' => $nextMonth->month]);
    }
}
