<?php

namespace App\Http\Controllers;

use App\Services\OpenAIService;
use Illuminate\Http\Request;

class AIController extends Controller
{
    public function __invoke(Request $request, OpenAIService $openAI)
    {
        $request->validate([
            'goal' => 'required|string',
            'category' => 'required|string',
            'difficulty' => 'required|string'
        ]);

        $plan = $openAI->generateGoalPlan(
            $request->goal,
            $request->category,
            $request->difficulty
        );

        return response()->json(['plan' => $plan]);
    }
}