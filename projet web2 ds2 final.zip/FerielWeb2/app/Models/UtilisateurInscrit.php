<?php

namespace App\Models;

use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class UtilisateurInscrit extends Authenticatable
{
    use HasFactory, Notifiable;

    protected $table = 'utilisateursinscrits';

    protected $fillable = [
        'nomcomplet',
        'email',
        'password'
    ];

    protected $hidden = [
        'password',
        'remember_token',
    ];

    public function objectifs()
    {
        return $this->hasMany(Objectif::class, 'utilisateur_id');
    }
}