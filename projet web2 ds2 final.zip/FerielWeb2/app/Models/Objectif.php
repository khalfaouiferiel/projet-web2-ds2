<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Objectif extends Model
{
    use HasFactory;

    protected $fillable = [
        'titre',
        'description',
        'date_limite',
        'categorie',
        'utilisateur_id',
        'ville',       
        'pays',        
    ];

    public function scopeByCategorie($query, $categorie)
    {
        return $query->where('categorie', $categorie);
    }

    public function utilisateur()
    {
        return $this->belongsTo(UtilisateurInscrit::class, 'utilisateur_id');
    }

    public function etapes()
    {
        return $this->hasMany(Etape::class);
    }
}
